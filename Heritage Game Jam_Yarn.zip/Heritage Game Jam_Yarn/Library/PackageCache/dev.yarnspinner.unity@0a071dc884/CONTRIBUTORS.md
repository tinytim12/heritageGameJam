# Contributors

The following people have contributed to the development of Yarn Spinner. If you submit a pull request, please add your name to the list below.

* 2015-ongoing: Secret Lab Team - Dr Jon Manning and Dr Paris Buttfield-Addison <lab@secretlab.com.au>
* 2017: Rev Peter Lawler <relwalretep@gmail.com>
* 2017: Dr Tim 'McJones' Nugent <tim@lonely.coffee>
* 2018: Damon 'demanrisu' Reece <de@coy.ninja>
* 2019: Tamme Schichler <tamme@schichler.dev>
* 2020: @Schroedingers-Cat